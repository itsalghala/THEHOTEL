
package RoomType;

import javax.swing.*;


public class RoomClass {
    public static void main(String[] args){
    RoomFrame room = new RoomFrame();
    room.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    room.setSize(400, 400);
    room.setVisible(true);
        
    }
    
}
